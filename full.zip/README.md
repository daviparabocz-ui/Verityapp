# Verity App

App Android (Kotlin + Jetpack Compose) que traz o Verity para a tela do seu
celular como um assistente de IA, usando a API do Gemini.

## Como abrir

1. Abra o Android Studio (recomendado: versão 2024.1 "Koala" ou mais recente).
2. `File > Open` e selecione esta pasta (`VerityApp/`).
3. Deixe o Android Studio baixar o Gradle Wrapper automaticamente na primeira
   sincronização (ele detecta que falta o `gradlew` e oferece para gerar/baixar).
4. Rode em um emulador ou dispositivo físico (minSdk 26 / Android 8.0+).

## Como conseguir uma API key do Gemini

1. Acesse https://aistudio.google.com/apikey
2. Crie uma key gratuita.
3. Abra o app, toque no ícone de engrenagem (⚙) e cole a key.

## Estrutura do projeto

```
app/src/main/java/com/verity/app/
├── data/
│   ├── ApiKeyStore.kt          # Armazena a API key criptografada
│   ├── GeminiRepository.kt     # Chamada REST à API do Gemini
│   └── VeritySystemPrompt.kt   # Prompt de sistema (personalidade + regras de tag)
├── domain/
│   ├── VerityAction.kt         # Enum com todos os emotes disponíveis e seus frames
│   ├── ChatModels.kt           # Modelos de mensagem/evento
│   └── EmoteParser.kt          # Tokeniza a resposta em texto + tags
├── ui/chat/
│   ├── VerityAnimator.kt       # Máquina de estado da animação do sprite
│   ├── ChatViewModel.kt        # Orquestra envio de mensagem + fila de eventos
│   ├── ChatViewModelFactory.kt
│   ├── ChatScreen.kt           # Tela principal
│   └── SettingsScreen.kt       # Tela de configuração da API key
└── MainActivity.kt
```

## Como funciona o sistema de emotes

O Gemini é instruído (via `VeritySystemPrompt`) a inserir tags como
`<wink>`, `<spin>`, `<speak_open>` no meio do texto da resposta. O
`EmoteParser` quebra essa resposta em uma lista ordenada de eventos
(`Text` ou `Emote`), que o `ChatViewModel` consome sequencialmente:

- **Texto**: exibido letra por letra (efeito "máquina de escrever").
- **Tags de fala** (`speak_open`, `speak_closed`, `serious_speak`): tocam em
  loop contínuo enquanto o próximo trecho de texto é digitado.
- **Tags de ação** (`spin`, `wink`, `glitch`): pausam o fluxo, tocam a
  sequência completa uma vez, esperam +230ms, e só então liberam o texto
  seguinte.

## Emotes disponíveis atualmente

| Tag | Frames | Comportamento |
|---|---|---|
| `idle` | 1 frame | repouso padrão |
| `serious_idle` | 1 frame | repouso sério |
| `spin` | 3 frames | gira, bloqueia até terminar |
| `wink` | 3 frames | pisca, bloqueia até terminar |
| `glitch` | 2 frames | falha visual, bloqueia até terminar |
| `speak_open` | 2 frames | fala de boca aberta, loop |
| `speak_closed` | 2 frames | fala de olhos fechados, loop |
| `serious_speak` | 2 frames | fala séria, loop |

## Próximos passos sugeridos

- [ ] Adicionar suporte a `<spin-R>` / `<spin-L>` quando você tiver os
      frames direcionais prontos no Scratch (hoje `spin` é genérico).
- [ ] TTS (texto-para-voz) sincronizado com as animações de fala.
- [ ] Suporte a múltiplas APIs (Claude, ChatGPT) via uma interface
      `AiRepository` comum.
- [ ] Ícone de launcher definitivo (hoje usa o sprite `idle` como placeholder).
- [ ] Persistir histórico de conversa entre sessões (hoje é limpo ao fechar o app).
