package com.verity.app.domain

import com.verity.app.R

/**
 * Uma ação/emote do Verity. Cada ação é uma sequência de 1+ frames (drawables)
 * tocados em ordem. [loop] indica se a sequência deve repetir enquanto não
 * houver próximo evento (usado pelos estados de "falando").
 */
enum class VerityAction(
    val tag: String,
    val frames: List<Int>,
    val frameDurationMs: Long = 120L,
    val loop: Boolean = false
) {
    IDLE(
        tag = "idle",
        frames = listOf(R.drawable.verity_idle)
    ),
    SERIOUS_IDLE(
        tag = "serious_idle",
        frames = listOf(R.drawable.verity_serious_idle)
    ),
    SPIN(
        tag = "spin",
        frames = listOf(
            R.drawable.verity_spin_001,
            R.drawable.verity_spin_002,
            R.drawable.verity_spin_003
        )
    ),
    WINK(
        tag = "wink",
        frames = listOf(
            R.drawable.verity_wink_001,
            R.drawable.verity_wink_002,
            R.drawable.verity_wink_003
        )
    ),
    GLITCH(
        tag = "glitch",
        frames = listOf(
            R.drawable.verity_glitch_001,
            R.drawable.verity_glitch_002
        )
    ),
    SPEAK_OPEN(
        tag = "speak_open",
        frames = listOf(
            R.drawable.verity_speak_open_001,
            R.drawable.verity_speak_open_002
        ),
        loop = true
    ),
    SPEAK_CLOSED(
        tag = "speak_closed",
        frames = listOf(
            R.drawable.verity_speak_closed_001,
            R.drawable.verity_speak_closed_002
        ),
        loop = true
    ),
    SERIOUS_SPEAK(
        tag = "serious_speak",
        frames = listOf(
            R.drawable.verity_serious_speak_001,
            R.drawable.verity_serious_speak_002
        ),
        loop = true
    );

    /** Duração total de UMA passada pela sequência (sem considerar loop). */
    fun singlePassDurationMs(): Long = frameDurationMs * frames.size

    companion object {
        private val byTag = entries.associateBy { it.tag }

        fun fromTag(tag: String): VerityAction? = byTag[tag.trim().lowercase()]

        /** Ações "de fala" que a IA pode escolher livremente para o texto corrido (modo normal). */
        val speakingActions = listOf(SPEAK_OPEN, SPEAK_CLOSED)
    }
}

/**
 * Humor persistente do Verity. Não é uma animação em si — é um estado que
 * decide QUAL variante de idle/fala é usada por padrão. Uma vez setado por
 * uma tag <normal>/<serious> numa resposta, permanece até a próxima resposta
 * que trocar o modo (persiste entre mensagens, não só dentro de uma resposta).
 */
enum class VerityMood(val tag: String) {
    NORMAL("normal"),
    SERIOUS("serious");

    /** A ação de idle correspondente a este humor. */
    fun idleAction(): VerityAction = when (this) {
        NORMAL -> VerityAction.IDLE
        SERIOUS -> VerityAction.SERIOUS_IDLE
    }

    companion object {
        private val byTag = entries.associateBy { it.tag }

        fun fromTag(tag: String): VerityMood? = byTag[tag.trim().lowercase()]
    }
}
