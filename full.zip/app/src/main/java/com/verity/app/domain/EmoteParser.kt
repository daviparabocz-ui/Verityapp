package com.verity.app.domain

/**
 * Converte a resposta crua do modelo (texto com tags tipo "<wink>" embutidas)
 * em uma lista ordenada de [ResponseEvent] que a UI consome sequencialmente.
 *
 * Tolerante a variações: case-insensitive, aceita hífen ou underscore
 * (<speak-open> == <speak_open>), ignora espaços extras dentro da tag,
 * e tags desconhecidas são descartadas silenciosamente (não quebram o fluxo,
 * apenas não geram uma animação).
 */
object EmoteParser {

    private val tagRegex = Regex("<\\s*([a-zA-Z_\\-]+)\\s*>")

    fun parse(raw: String): List<ResponseEvent> {
        val events = mutableListOf<ResponseEvent>()
        var lastIndex = 0

        for (match in tagRegex.findAll(raw)) {
            val textBefore = raw.substring(lastIndex, match.range.first)
            if (textBefore.isNotEmpty()) {
                events.add(ResponseEvent.Text(textBefore))
            }

            val normalizedTag = match.groupValues[1].replace('-', '_').lowercase()
            val mood = VerityMood.fromTag(normalizedTag)
            val action = VerityAction.fromTag(normalizedTag)
            when {
                mood != null -> events.add(ResponseEvent.ModeChange(mood))
                action != null -> events.add(ResponseEvent.Emote(action))
                // Tag desconhecida: ignorada de propósito, sem adicionar evento.
            }

            lastIndex = match.range.last + 1
        }

        val remaining = raw.substring(lastIndex)
        if (remaining.isNotEmpty()) {
            events.add(ResponseEvent.Text(remaining))
        }

        return events
    }
}
