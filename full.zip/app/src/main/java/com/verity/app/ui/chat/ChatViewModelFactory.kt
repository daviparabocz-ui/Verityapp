package com.verity.app.ui.chat

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.verity.app.data.ApiKeyStore
import com.verity.app.data.GeminiRepository

class ChatViewModelFactory(private val appContext: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val apiKeyStore = ApiKeyStore(appContext)
        val repository = GeminiRepository(apiKeyStore)
        @Suppress("UNCHECKED_CAST")
        return ChatViewModel(apiKeyStore, repository) as T
    }
}
