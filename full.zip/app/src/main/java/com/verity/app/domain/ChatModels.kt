package com.verity.app.domain

/** Um item da fila de reprodução gerada a partir da resposta do modelo. */
sealed class ResponseEvent {
    data class Text(val content: String) : ResponseEvent()
    data class Emote(val action: VerityAction) : ResponseEvent()
    /** <normal>/<serious>: não anima nada sozinho, só troca o humor persistente. */
    data class ModeChange(val mood: VerityMood) : ResponseEvent()
}

/** Papel do autor de uma mensagem no histórico do chat. */
enum class ChatRole { USER, MODEL }

/**
 * Um arquivo (mídia ou documento) anexado a uma mensagem do usuário, já lido
 * e codificado em base64, pronto para ir no corpo da requisição pro Gemini
 * como `inlineData`.
 */
data class ChatAttachment(
    val displayName: String,
    val mimeType: String,
    val base64Data: String
)

data class ChatMessage(
    val role: ChatRole,
    val content: String,
    val attachment: ChatAttachment? = null
)
