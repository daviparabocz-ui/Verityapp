package com.verity.app.domain

/** Um item da fila de reprodução gerada a partir da resposta do modelo. */
sealed class ResponseEvent {
    data class Text(val content: String) : ResponseEvent()
    data class Emote(val action: VerityAction) : ResponseEvent()
    /** <normal>/<serious>: não anima nada sozinho, só troca o humor persistente. */
    data class ModeChange(val mood: VerityMood) : ResponseEvent()
}

/** Papel do autor de uma mensagem no histórico do chat. */
enum class ChatRole { USER, MODEL }

data class ChatMessage(
    val role: ChatRole,
    val content: String
)
