package com.verity.app.ui.chat

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.verity.app.domain.VerityAction
import com.verity.app.domain.VerityMood
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Buffer extra depois que uma sequência de animação termina, antes de liberar o texto seguinte. */
private const val POST_ANIMATION_BUFFER_MS = 230L

/**
 * Controla qual frame do Verity está visível e toca sequências de ação
 * de forma suspensa (bloqueante para quem chama), para sincronizar com
 * o efeito de "máquina de escrever" do texto.
 *
 * [currentMood] é o humor persistente (normal/serious): decide para qual
 * idle a animação retorna depois de uma ação, e é setado externamente pelo
 * ChatViewModel quando uma tag <normal>/<serious> aparece na resposta.
 */
class VerityAnimator(private val scope: CoroutineScope) {

    var currentMood: VerityMood = VerityMood.NORMAL

    var currentDrawableRes by mutableIntStateOf(currentMood.idleAction().frames.first())
        private set

    private var loopJob: Job? = null

    /** Toca uma ação até o fim (uma passada) + buffer, depois volta pro idle do humor atual. Suspende até terminar. */
    suspend fun playAction(action: VerityAction) {
        stopLoop()
        for (frame in action.frames) {
            currentDrawableRes = frame
            delay(action.frameDurationMs)
        }
        delay(POST_ANIMATION_BUFFER_MS)
        currentDrawableRes = currentMood.idleAction().frames.first()
    }

    /**
     * Ativa um loop contínuo (usado para speak_open/speak_closed enquanto o texto
     * está sendo "digitado"). Roda em background e pode ser interrompido por [stopLoop]
     * ou pela próxima chamada a [playAction]/[playLoop].
     */
    fun playLoop(action: VerityAction) {
        stopLoop()
        loopJob = scope.launch {
            while (true) {
                for (frame in action.frames) {
                    currentDrawableRes = frame
                    delay(action.frameDurationMs)
                }
            }
        }
    }

    fun stopLoop() {
        loopJob?.cancel()
        loopJob = null
    }

    fun resetToIdle() {
        stopLoop()
        currentDrawableRes = currentMood.idleAction().frames.first()
    }
}
