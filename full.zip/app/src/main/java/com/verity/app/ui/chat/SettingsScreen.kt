package com.verity.app.ui.chat

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.verity.app.data.DEFAULT_GEMINI_MODEL

/**
 * Modelos Gemini conhecidos no momento em que este app foi escrito.
 * A Google costuma descontinuar modelos com alguma frequência, então
 * também oferecemos "Personalizado..." para o usuário digitar qualquer
 * string de modelo nova sem precisar de uma atualização do app.
 */
private val KNOWN_MODELS = listOf(
    "gemini-3.8-flash",
    "gemini-3.7-flash",
    "gemini-3.5-flash",
    "gemini-3.1-pro",
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite"
)

private const val CUSTOM_OPTION = "Personalizado..."

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ChatViewModel,
    onBack: () -> Unit
) {
    var keyInput by remember { mutableStateOf("") }

    var modelMenuExpanded by remember { mutableStateOf(false) }
    val isKnownModel = viewModel.selectedModel in KNOWN_MODELS
    var selectedDropdownLabel by remember(viewModel.selectedModel) {
        mutableStateOf(if (isKnownModel) viewModel.selectedModel else CUSTOM_OPTION)
    }
    var customModelInput by remember(viewModel.selectedModel) {
        mutableStateOf(if (isKnownModel) "" else viewModel.selectedModel)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Configurações") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Text("←")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp)) {
            Text(
                text = "API Key do Gemini",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Você pode gerar uma key gratuita em aistudio.google.com/apikey",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = keyInput,
                onValueChange = { keyInput = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Cole sua API key aqui") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true
            )

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = {
                    if (keyInput.isNotBlank()) {
                        viewModel.saveApiKey(keyInput)
                        onBack()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Salvar")
            }

            if (viewModel.hasApiKey) {
                Spacer(Modifier.height(8.dp))
                TextButton(
                    onClick = { viewModel.clearApiKey() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Remover key salva")
                }
            }

            Spacer(Modifier.height(24.dp))
            HorizontalDivider()
            Spacer(Modifier.height(24.dp))

            Text(
                text = "Modelo",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "A Google descontinua modelos com frequência. Se aparecer um erro " +
                    "de \"modelo não encontrado\", troque aqui pelo nome mais recente.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(16.dp))

            ExposedDropdownMenuBox(
                expanded = modelMenuExpanded,
                onExpandedChange = { modelMenuExpanded = it }
            ) {
                OutlinedTextField(
                    value = selectedDropdownLabel,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Modelo Gemini") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = modelMenuExpanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )

                ExposedDropdownMenu(
                    expanded = modelMenuExpanded,
                    onDismissRequest = { modelMenuExpanded = false }
                ) {
                    KNOWN_MODELS.forEach { modelName ->
                        DropdownMenuItem(
                            text = { Text(modelName) },
                            onClick = {
                                selectedDropdownLabel = modelName
                                modelMenuExpanded = false
                                viewModel.saveModel(modelName)
                            }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(CUSTOM_OPTION) },
                        onClick = {
                            selectedDropdownLabel = CUSTOM_OPTION
                            modelMenuExpanded = false
                        }
                    )
                }
            }

            if (selectedDropdownLabel == CUSTOM_OPTION) {
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = customModelInput,
                    onValueChange = { customModelInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Nome exato do modelo") },
                    placeholder = { Text("ex: gemini-4.0-flash") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (customModelInput.isNotBlank()) {
                            viewModel.saveModel(customModelInput)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = customModelInput.isNotBlank()
                ) {
                    Text("Usar este modelo")
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                text = "Modelo atual: ${viewModel.selectedModel}",
                style = MaterialTheme.typography.labelSmall
            )

            if (viewModel.selectedModel != DEFAULT_GEMINI_MODEL) {
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = { viewModel.saveModel(DEFAULT_GEMINI_MODEL) }) {
                    Text("Restaurar padrão ($DEFAULT_GEMINI_MODEL)")
                }
            }
        }
    }
}
