package com.verity.app.ui.chat

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.verity.app.data.ApiKeyStore
import com.verity.app.data.GeminiRepository
import com.verity.app.data.GeminiResult
import com.verity.app.domain.ChatAttachment
import com.verity.app.domain.ChatMessage
import com.verity.app.domain.ChatRole
import com.verity.app.domain.EmoteParser
import com.verity.app.domain.ResponseEvent
import com.verity.app.domain.VerityAction
import com.verity.app.domain.VerityMood
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Velocidade da digitação, ms por caractere. */
private const val TYPEWRITER_DELAY_MS = 18L

class ChatViewModel(
    private val apiKeyStore: ApiKeyStore,
    private val repository: GeminiRepository
) : ViewModel() {

    val animator = VerityAnimator(viewModelScope)

    var history by mutableStateOf(listOf<ChatMessage>())
        private set

    /** Texto atualmente exibido no balão do Verity (vai crescendo com o efeito de máquina de escrever). */
    var displayedText by mutableStateOf("")
        private set

    /** Última resposta crua do modelo, com as tags <> ainda no texto (para o modo de depuração). */
    var lastRawResponse by mutableStateOf("")
        private set

    /** Mostra o texto crudo (com tags) em vez do texto digitado/animado. Controlado pela UI de settings/debug. */
    var showRawResponse by mutableStateOf(false)
        private set

    fun updateShowRawResponse(value: Boolean) {
        showRawResponse = value
    }

    /** Arquivo (mídia ou documento) escolhido pelo usuário, ainda não enviado. */
    var pendingAttachment by mutableStateOf<ChatAttachment?>(null)
        private set

    fun attachPendingFile(attachment: ChatAttachment) {
        pendingAttachment = attachment
    }

    fun clearPendingAttachment() {
        pendingAttachment = null
    }

    /**
     * Humor persistente do Verity (normal/serious). Uma vez trocado por uma tag
     * <normal>/<serious> numa resposta, permanece até a próxima resposta que o
     * trocar de novo — sobrevive entre mensagens diferentes, não só dentro de uma.
     */
    var currentMood by mutableStateOf(VerityMood.NORMAL)
        private set

    var isBusy by mutableStateOf(false)
        private set

    var errorMessage by mutableStateOf<String?>(null)
        private set

    var hasApiKey by mutableStateOf(apiKeyStore.hasKey())
        private set

    /** Modelo Gemini atualmente selecionado (persistido via ApiKeyStore). */
    var selectedModel by mutableStateOf(apiKeyStore.getModel())
        private set

    fun saveApiKey(key: String) {
        apiKeyStore.saveKey(key)
        hasApiKey = apiKeyStore.hasKey()
    }

    fun clearApiKey() {
        apiKeyStore.clearKey()
        hasApiKey = false
    }

    fun saveModel(model: String) {
        apiKeyStore.saveModel(model)
        selectedModel = model
    }

    fun sendMessage(userText: String) {
        val attachment = pendingAttachment
        if ((userText.isBlank() && attachment == null) || isBusy) return

        errorMessage = null
        val updatedHistory = history + ChatMessage(ChatRole.USER, userText, attachment)
        history = updatedHistory
        pendingAttachment = null
        isBusy = true
        displayedText = ""

        viewModelScope.launch {
            when (val result = repository.sendMessage(updatedHistory)) {
                is GeminiResult.Success -> {
                    history = history + ChatMessage(ChatRole.MODEL, result.text)
                    lastRawResponse = result.text
                    playResponse(result.text)
                }
                is GeminiResult.Error -> {
                    errorMessage = result.message
                }
            }
            isBusy = false
        }
    }

    /** Consome a fila de eventos: digita texto char-by-char, pausa em tags para animar. */
    private suspend fun playResponse(rawText: String) {
        val events = EmoteParser.parse(rawText)

        for (event in events) {
            when (event) {
                is ResponseEvent.Text -> {
                    typeText(event.content)
                }
                is ResponseEvent.ModeChange -> {
                    // Troca o humor persistente. Não anima nada por si só — só afeta
                    // qual idle/fala padrão o animator usa de agora em diante,
                    // incluindo em mensagens futuras.
                    currentMood = event.mood
                    animator.currentMood = event.mood
                }
                is ResponseEvent.Emote -> {
                    val resolvedAction = resolveForMood(event.action)
                    if (resolvedAction in VerityAction.speakingActions ||
                        resolvedAction == VerityAction.SERIOUS_SPEAK
                    ) {
                        // Ações de fala tocam em loop enquanto o texto seguinte é digitado;
                        // então apenas trocamos o loop e seguimos, sem bloquear.
                        animator.playLoop(resolvedAction)
                    } else {
                        // Ações "físicas" (spin, wink, glitch) bloqueiam até terminar + buffer.
                        // Não dependem do humor: seguem iguais em normal e serious.
                        animator.playAction(resolvedAction)
                    }
                }
            }
        }

        animator.resetToIdle()
    }

    /**
     * Enquanto em modo SERIOUS, qualquer tag de fala normal (speak_open/speak_closed)
     * que a IA ainda emitir por hábito é redirecionada para serious_speak, para o
     * visual não quebrar o clima. Ações físicas (spin/wink/glitch) e o próprio
     * serious_speak passam direto, sem alteração.
     */
    private fun resolveForMood(action: VerityAction): VerityAction {
        if (currentMood == VerityMood.SERIOUS && action in VerityAction.speakingActions) {
            return VerityAction.SERIOUS_SPEAK
        }
        return action
    }

    private suspend fun typeText(text: String) {
        for (char in text) {
            displayedText += char
            delay(TYPEWRITER_DELAY_MS)
        }
    }
}
