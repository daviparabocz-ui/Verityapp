package com.verity.app.ui.chat

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.verity.app.data.ApiKeyStore
import com.verity.app.data.DEFAULT_GEMINI_MODEL
import com.verity.app.data.GeminiRepository
import com.verity.app.data.GeminiResult
import com.verity.app.domain.ChatAttachment
import com.verity.app.domain.ChatMessage
import com.verity.app.domain.ChatRole
import com.verity.app.domain.EmoteParser
import com.verity.app.domain.ResponseEvent
import com.verity.app.domain.VerityAction
import com.verity.app.domain.VerityMood
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Velocidade da digitação, ms por caractere. */
private const val TYPEWRITER_DELAY_MS = 18L

/**
 * Sem Compose (que traria `mutableStateOf`), a tela observa um único
 * LiveData com todo o estado relevante da UI, atualizado imutavelmente
 * (`copy()`) a cada mudança — o equivalente "clássico" ao que a
 * combinação de vários `by mutableStateOf` fazia antes.
 */
data class ChatUiState(
    val displayedText: String = "",
    val lastRawResponse: String = "",
    val showRawResponse: Boolean = false,
    val pendingAttachment: ChatAttachment? = null,
    val isBusy: Boolean = false,
    val errorMessage: String? = null,
    val hasApiKey: Boolean = false,
    val selectedModel: String = DEFAULT_GEMINI_MODEL,
    val verityDrawableRes: Int = VerityMood.NORMAL.idleAction().frames.first()
)

class ChatViewModel(
    private val apiKeyStore: ApiKeyStore,
    private val repository: GeminiRepository
) : ViewModel() {

    private val animator = VerityAnimator(viewModelScope) { frame ->
        _uiState.value = _uiState.value!!.copy(verityDrawableRes = frame)
    }

    private val _uiState = MutableLiveData(
        ChatUiState(
            hasApiKey = apiKeyStore.hasKey(),
            selectedModel = apiKeyStore.getModel(),
            verityDrawableRes = animator.currentDrawableRes
        )
    )
    val uiState: LiveData<ChatUiState> = _uiState

    private var history = listOf<ChatMessage>()
    private var currentMood = VerityMood.NORMAL

    private fun update(transform: ChatUiState.() -> ChatUiState) {
        _uiState.value = _uiState.value!!.transform()
    }

    fun updateShowRawResponse(value: Boolean) = update { copy(showRawResponse = value) }

    fun attachPendingFile(attachment: ChatAttachment) = update { copy(pendingAttachment = attachment) }

    fun clearPendingAttachment() = update { copy(pendingAttachment = null) }

    fun saveApiKey(key: String) {
        apiKeyStore.saveKey(key)
        update { copy(hasApiKey = apiKeyStore.hasKey()) }
    }

    fun clearApiKey() {
        apiKeyStore.clearKey()
        update { copy(hasApiKey = false) }
    }

    fun saveModel(model: String) {
        apiKeyStore.saveModel(model)
        update { copy(selectedModel = model) }
    }

    /** Chamado ao voltar da tela de Configurações (Activity separada), que mexe
     * direto no ApiKeyStore sem passar por este ViewModel. */
    fun refreshFromStore() {
        update { copy(hasApiKey = apiKeyStore.hasKey(), selectedModel = apiKeyStore.getModel()) }
    }

    fun sendMessage(userText: String) {
        val current = _uiState.value!!
        val attachment = current.pendingAttachment
        if ((userText.isBlank() && attachment == null) || current.isBusy) return

        history = history + ChatMessage(ChatRole.USER, userText, attachment)
        update {
            copy(
                errorMessage = null,
                pendingAttachment = null,
                isBusy = true,
                displayedText = ""
            )
        }

        viewModelScope.launch {
            when (val result = repository.sendMessage(history)) {
                is GeminiResult.Success -> {
                    history = history + ChatMessage(ChatRole.MODEL, result.text)
                    update { copy(lastRawResponse = result.text) }
                    playResponse(result.text)
                }
                is GeminiResult.Error -> {
                    update { copy(errorMessage = result.message) }
                }
            }
            update { copy(isBusy = false) }
        }
    }

    /** Consome a fila de eventos: digita texto char-by-char, pausa em tags para animar. */
    private suspend fun playResponse(rawText: String) {
        val events = EmoteParser.parse(rawText)

        for (event in events) {
            when (event) {
                is ResponseEvent.Text -> {
                    typeText(event.content)
                }
                is ResponseEvent.ModeChange -> {
                    // Troca o humor persistente. Não anima nada por si só — só afeta
                    // qual idle/fala padrão o animator usa de agora em diante,
                    // incluindo em mensagens futuras.
                    currentMood = event.mood
                    animator.currentMood = event.mood
                }
                is ResponseEvent.Emote -> {
                    val resolvedAction = resolveForMood(event.action)
                    if (resolvedAction in VerityAction.speakingActions ||
                        resolvedAction == VerityAction.SERIOUS_SPEAK
                    ) {
                        // Ações de fala tocam em loop enquanto o texto seguinte é digitado;
                        // então apenas trocamos o loop e seguimos, sem bloquear.
                        animator.playLoop(resolvedAction)
                    } else {
                        // Ações "físicas" (spin, wink, glitch) bloqueiam até terminar + buffer.
                        // Não dependem do humor: seguem iguais em normal e serious.
                        animator.playAction(resolvedAction)
                    }
                }
            }
        }

        animator.resetToIdle()
    }

    /**
     * Enquanto em modo SERIOUS, qualquer tag de fala normal (speak_open/speak_closed)
     * que a IA ainda emitir por hábito é redirecionada para serious_speak, para o
     * visual não quebrar o clima. Ações físicas (spin/wink/glitch) e o próprio
     * serious_speak passam direto, sem alteração.
     */
    private fun resolveForMood(action: VerityAction): VerityAction {
        if (currentMood == VerityMood.SERIOUS && action in VerityAction.speakingActions) {
            return VerityAction.SERIOUS_SPEAK
        }
        return action
    }

    private suspend fun typeText(text: String) {
        for (char in text) {
            update { copy(displayedText = displayedText + char) }
            delay(TYPEWRITER_DELAY_MS)
        }
    }
}
