package com.verity.app.data

import android.os.Build
import java.io.IOException
import java.net.InetAddress
import java.net.Socket
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.X509TrustManager

/**
 * Nas APIs 16 a 20, o Android já sabe falar TLSv1.1/TLSv1.2, mas o
 * SSLSocketFactory padrão vem com esses protocolos DESABILITADOS por padrão
 * (só foram habilitados por padrão a partir da API 21). Como a API do Gemini
 * hoje exige TLS 1.2, sem esse ajuste toda chamada de rede falharia em um
 * KitKat de verdade. Isso não afeta em nada o app rodando em Android mais
 * novo (o guard de SDK_INT abaixo simplesmente não faz nada nesse caso).
 */
internal class TlsSocketFactoryCompat(
    private val delegate: SSLSocketFactory
) : SSLSocketFactory() {

    override fun getDefaultCipherSuites(): Array<String> = delegate.defaultCipherSuites
    override fun getSupportedCipherSuites(): Array<String> = delegate.supportedCipherSuites

    @Throws(IOException::class)
    override fun createSocket(s: Socket, host: String, port: Int, autoClose: Boolean): Socket =
        patch(delegate.createSocket(s, host, port, autoClose))

    @Throws(IOException::class)
    override fun createSocket(host: String, port: Int): Socket =
        patch(delegate.createSocket(host, port))

    @Throws(IOException::class)
    override fun createSocket(host: String, port: Int, localHost: InetAddress, localPort: Int): Socket =
        patch(delegate.createSocket(host, port, localHost, localPort))

    @Throws(IOException::class)
    override fun createSocket(host: InetAddress, port: Int): Socket =
        patch(delegate.createSocket(host, port))

    @Throws(IOException::class)
    override fun createSocket(
        address: InetAddress,
        port: Int,
        localAddress: InetAddress,
        localPort: Int
    ): Socket = patch(delegate.createSocket(address, port, localAddress, localPort))

    private fun patch(socket: Socket): Socket {
        if (socket is SSLSocket) {
            socket.enabledProtocols = arrayOf("TLSv1.1", "TLSv1.2")
        }
        return socket
    }

    companion object {
        /** Aplica o patch só onde ele é necessário (API 16-20); em API 21+ é no-op. */
        fun applyIfNeeded(builder: okhttp3.OkHttpClient.Builder) {
            if (Build.VERSION.SDK_INT !in Build.VERSION_CODES.JELLY_BEAN..20) return

            try {
                val trustManagerFactory = javax.net.ssl.TrustManagerFactory.getInstance(
                    javax.net.ssl.TrustManagerFactory.getDefaultAlgorithm()
                )
                trustManagerFactory.init(null as java.security.KeyStore?)
                val trustManagers = trustManagerFactory.trustManagers
                val x509TrustManager = trustManagers.filterIsInstance<X509TrustManager>().first()

                val sslContext = SSLContext.getInstance("TLS")
                sslContext.init(null, arrayOf(x509TrustManager), null)

                builder.sslSocketFactory(
                    TlsSocketFactoryCompat(sslContext.socketFactory),
                    x509TrustManager
                )
            } catch (e: Exception) {
                // Se algo der errado aqui, seguimos com o factory padrão em vez
                // de derrubar o app; a chamada de rede simplesmente vai falhar
                // com o erro de TLS original nesse caso.
            }
        }
    }
}
