package com.verity.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.util.Base64
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import com.verity.app.domain.ChatAttachment
import com.verity.app.ui.chat.ChatUiState
import com.verity.app.ui.chat.ChatViewModel
import com.verity.app.ui.chat.ChatViewModelFactory
import com.verity.app.ui.chat.SettingsActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Tamanho máximo aceito para um anexo (a API do Gemini tem um limite de payload inline). */
private const val MAX_ATTACHMENT_BYTES = 15L * 1024 * 1024
private const val REQUEST_ATTACH_MEDIA = 1001
private const val REQUEST_ATTACH_FILE = 1002

private class AttachmentTooLargeException : Exception()

/**
 * Tela de chat, agora em Views/XML clássicas (API 19 não roda Compose).
 * O tema Holo (definido em themes.xml) já cuida do fundo cinza stock e do
 * visual dos widgets nativos (Switch, Button, PopupMenu, ProgressBar etc).
 */
class MainActivity : Activity(), ViewModelStoreOwner {

    override val viewModelStore: ViewModelStore = ViewModelStore()

    private lateinit var viewModel: ChatViewModel
    private val activityScope: CoroutineScope = MainScope()
    private lateinit var uiStateObserver: Observer<ChatUiState>

    private lateinit var verityImage: android.widget.ImageView
    private lateinit var switchRaw: Switch
    private lateinit var responseText: TextView
    private lateinit var errorText: TextView
    private lateinit var noKeyHint: TextView
    private lateinit var btnAttach: Button
    private lateinit var attachmentChip: View
    private lateinit var attachmentName: TextView
    private lateinit var attachmentError: TextView
    private lateinit var inputText: EditText
    private lateinit var progressSending: ProgressBar
    private lateinit var btnSend: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "Verity"

        viewModel = ViewModelProvider(
            this,
            ChatViewModelFactory(applicationContext)
        )[ChatViewModel::class.java]

        bindViews()
        wireListeners()

        uiStateObserver = Observer { state -> render(state) }
        viewModel.uiState.observeForever(uiStateObserver)
    }

    private fun bindViews() {
        verityImage = findViewById(R.id.verity_sprite)
        switchRaw = findViewById(R.id.switch_raw)
        responseText = findViewById(R.id.response_text)
        errorText = findViewById(R.id.error_text)
        noKeyHint = findViewById(R.id.no_key_hint)
        btnAttach = findViewById(R.id.btn_attach)
        attachmentChip = findViewById(R.id.attachment_chip)
        attachmentName = findViewById(R.id.attachment_name)
        attachmentError = findViewById(R.id.attachment_error)
        inputText = findViewById(R.id.input_text)
        progressSending = findViewById(R.id.progress_sending)
        btnSend = findViewById(R.id.btn_send)
    }

    private fun wireListeners() {
        switchRaw.setOnCheckedChangeListener { _: CompoundButton, checked: Boolean ->
            viewModel.updateShowRawResponse(checked)
        }

        // Mesmo padrão do app original: um único fluxo de "escolher arquivo",
        // só muda a lista de mimeTypes conforme a opção do popup.
        btnAttach.setOnClickListener { anchor ->
            val popup = PopupMenu(this, anchor)
            popup.menuInflater.inflate(R.menu.attach_menu, popup.menu)
            popup.setOnMenuItemClickListener { item: MenuItem ->
                when (item.itemId) {
                    R.id.attach_media -> {
                        launchDocumentPicker(arrayOf("audio/*", "video/*"), REQUEST_ATTACH_MEDIA)
                        true
                    }
                    R.id.attach_file -> {
                        launchDocumentPicker(arrayOf("*/*"), REQUEST_ATTACH_FILE)
                        true
                    }
                    else -> false
                }
            }
            popup.show()
        }

        attachmentChip.findViewById<TextView>(R.id.attachment_remove).setOnClickListener {
            viewModel.clearPendingAttachment()
        }

        btnSend.setOnClickListener {
            viewModel.sendMessage(inputText.text.toString())
            inputText.setText("")
        }

        // Sem recomposição automática (isso não é Compose), o botão "Enviar"
        // precisa ser reavaliado manualmente a cada tecla digitada.
        inputText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = updateSendButtonEnabled()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
        })
    }

    private fun updateSendButtonEnabled() {
        val state = viewModel.uiState.value ?: return
        btnSend.isEnabled = !state.isBusy && state.hasApiKey &&
            (inputText.text.isNotBlank() || state.pendingAttachment != null)
    }

    /** ACTION_OPEN_DOCUMENT (Storage Access Framework) já existe desde a própria API 19. */
    private fun launchDocumentPicker(mimeTypes: Array<String>, requestCode: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
        }
        startActivityForResult(intent, requestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        if (requestCode != REQUEST_ATTACH_MEDIA && requestCode != REQUEST_ATTACH_FILE) return
        val uri = data?.data ?: return

        activityScope.launch {
            try {
                val attachment = readAttachment(this@MainActivity, uri)
                viewModel.attachPendingFile(attachment)
                setAttachmentError(null)
            } catch (e: AttachmentTooLargeException) {
                setAttachmentError("Arquivo muito grande (máx. 15 MB).")
            } catch (e: Exception) {
                setAttachmentError("Não foi possível ler o arquivo.")
            }
        }
    }

    private fun setAttachmentError(message: String?) {
        attachmentError.text = message.orEmpty()
        attachmentError.visibility = if (message == null) View.GONE else View.VISIBLE
    }

    private fun render(state: ChatUiState) {
        verityImage.setImageResource(state.verityDrawableRes)

        responseText.text = if (state.showRawResponse) state.lastRawResponse else state.displayedText

        errorText.text = state.errorMessage.orEmpty()
        errorText.visibility = if (state.errorMessage == null) View.GONE else View.VISIBLE

        noKeyHint.visibility = if (state.hasApiKey) View.GONE else View.VISIBLE

        val canAttach = state.hasApiKey && !state.isBusy
        btnAttach.isEnabled = canAttach

        val attachment = state.pendingAttachment
        if (attachment != null) {
            attachmentChip.visibility = View.VISIBLE
            attachmentName.text = attachment.displayName
        } else {
            attachmentChip.visibility = View.GONE
        }

        inputText.isEnabled = state.hasApiKey && !state.isBusy

        if (state.isBusy) {
            progressSending.visibility = View.VISIBLE
            btnSend.visibility = View.GONE
        } else {
            progressSending.visibility = View.GONE
            btnSend.visibility = View.VISIBLE
        }
        updateSendButtonEnabled()
    }

    override fun onDestroy() {
        super.onDestroy()
        activityScope.cancel()
        viewModel.uiState.removeObserver(uiStateObserver)
        if (isFinishing) {
            viewModelStore.clear()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_settings) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onResume() {
        super.onResume()
        // Ao voltar das configurações, o hasApiKey/selectedModel podem ter mudado.
        viewModel.refreshFromStore()
    }
}

/**
 * Lê o conteúdo de [uri] via ContentResolver, valida o tamanho e devolve já
 * codificado em base64, pronto para ir na requisição pro Gemini. Roda em
 * background (IO) porque envolve leitura de arquivo, potencialmente grande.
 */
private suspend fun readAttachment(context: Context, uri: Uri): ChatAttachment =
    withContext(Dispatchers.IO) {
        val resolver = context.contentResolver

        var displayName = "arquivo"
        var declaredSize: Long? = null
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex >= 0) cursor.getString(nameIndex)?.let { displayName = it }
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) declaredSize = cursor.getLong(sizeIndex)
            }
        }

        if ((declaredSize ?: 0L) > MAX_ATTACHMENT_BYTES) {
            throw AttachmentTooLargeException()
        }

        val mimeType = resolver.getType(uri) ?: "application/octet-stream"

        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Não foi possível abrir o arquivo.")

        if (bytes.size > MAX_ATTACHMENT_BYTES) {
            throw AttachmentTooLargeException()
        }

        ChatAttachment(
            displayName = displayName,
            mimeType = mimeType,
            base64Data = Base64.encodeToString(bytes, Base64.NO_WRAP)
        )
    }
