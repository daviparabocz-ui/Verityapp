package com.verity.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.verity.app.ui.chat.ChatScreen
import com.verity.app.ui.chat.ChatViewModel
import com.verity.app.ui.chat.ChatViewModelFactory
import com.verity.app.ui.chat.SettingsScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    VerityApp()
                }
            }
        }
    }
}

private enum class Screen { CHAT, SETTINGS }

@Composable
private fun VerityApp() {
    val viewModel: ChatViewModel = viewModel(
        factory = ChatViewModelFactory(LocalContext.current.applicationContext)
    )
    var currentScreen by remember { mutableStateOf(Screen.CHAT) }

    when (currentScreen) {
        Screen.CHAT -> ChatScreen(
            viewModel = viewModel,
            onOpenSettings = { currentScreen = Screen.SETTINGS }
        )
        Screen.SETTINGS -> SettingsScreen(
            viewModel = viewModel,
            onBack = { currentScreen = Screen.CHAT }
        )
    }
}
