package com.verity.app.data

import com.verity.app.domain.ChatAttachment
import com.verity.app.domain.ChatMessage
import com.verity.app.domain.ChatRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class GeminiResult {
    data class Success(val text: String) : GeminiResult()
    data class Error(val message: String) : GeminiResult()
}

class GeminiRepository(
    private val apiKeyStore: ApiKeyStore
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun sendMessage(history: List<ChatMessage>): GeminiResult = withContext(Dispatchers.IO) {
        val apiKey = apiKeyStore.getKey()
        if (apiKey.isNullOrBlank()) {
            return@withContext GeminiResult.Error("Nenhuma API key configurada.")
        }

        val model = apiKeyStore.getModel()
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

        val body = buildRequestBody(history)

        val request = Request.Builder()
            .url(url)
            .post(body.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    val rawMsg = try {
                        JSONObject(bodyString).optJSONObject("error")?.optString("message")
                    } catch (e: Exception) {
                        null
                    } ?: "Erro HTTP ${response.code}"

                    val hint = if (rawMsg.contains("not found", ignoreCase = true) ||
                        rawMsg.contains("no longer available", ignoreCase = true)
                    ) {
                        " Tente trocar o modelo nas configurações (⚙)."
                    } else ""

                    return@withContext GeminiResult.Error(rawMsg + hint)
                }

                val text = extractText(bodyString)
                if (text.isNullOrBlank()) {
                    GeminiResult.Error("Resposta vazia do modelo.")
                } else {
                    GeminiResult.Success(text)
                }
            }
        } catch (e: IOException) {
            GeminiResult.Error("Falha de rede: ${e.message}")
        } catch (e: Exception) {
            GeminiResult.Error("Erro inesperado: ${e.message}")
        }
    }

    private fun buildRequestBody(history: List<ChatMessage>): JSONObject {
        val contents = JSONArray()

        for (msg in history) {
            val role = if (msg.role == ChatRole.USER) "user" else "model"
            val parts = JSONArray()

            // Uma mensagem com anexo pode não ter texto (ex: só uma imagem/áudio),
            // então a parte de texto só entra se houver conteúdo de fato.
            if (msg.content.isNotBlank()) {
                parts.put(JSONObject().put("text", msg.content))
            }
            msg.attachment?.let { attachment ->
                parts.put(attachmentPart(attachment))
            }

            val entry = JSONObject()
                .put("role", role)
                .put("parts", parts)
            contents.put(entry)
        }

        val systemInstruction = JSONObject()
            .put(
                "parts",
                JSONArray().put(JSONObject().put("text", VeritySystemPrompt.build()))
            )

        return JSONObject()
            .put("contents", contents)
            .put("system_instruction", systemInstruction)
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.9)
                    .put("maxOutputTokens", 512)
            )
    }

    /** Converte um anexo lido localmente numa parte `inlineData` do formato esperado pela API do Gemini. */
    private fun attachmentPart(attachment: ChatAttachment): JSONObject {
        val inlineData = JSONObject()
            .put("mimeType", attachment.mimeType)
            .put("data", attachment.base64Data)
        return JSONObject().put("inlineData", inlineData)
    }

    private fun extractText(responseBody: String): String? {
        return try {
            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates") ?: return null
            if (candidates.length() == 0) return null
            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                sb.append(parts.getJSONObject(i).optString("text"))
            }
            sb.toString()
        } catch (e: Exception) {
            null
        }
    }
}
