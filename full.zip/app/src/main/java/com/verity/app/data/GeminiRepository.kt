package com.verity.app.data

import com.verity.app.domain.ChatMessage
import com.verity.app.domain.ChatRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class GeminiResult {
    data class Success(val text: String) : GeminiResult()
    data class Error(val message: String) : GeminiResult()
}

class GeminiRepository(
    private val apiKeyStore: ApiKeyStore
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    /** Modelo Gemini usado. Ajustável conforme necessidade/custo. */
    private val model = "gemini-2.0-flash"

    suspend fun sendMessage(history: List<ChatMessage>): GeminiResult = withContext(Dispatchers.IO) {
        val apiKey = apiKeyStore.getKey()
        if (apiKey.isNullOrBlank()) {
            return@withContext GeminiResult.Error("Nenhuma API key configurada.")
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

        val body = buildRequestBody(history)

        val request = Request.Builder()
            .url(url)
            .post(body.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    val errMsg = try {
                        JSONObject(bodyString).optJSONObject("error")?.optString("message")
                    } catch (e: Exception) {
                        null
                    } ?: "Erro HTTP ${response.code}"
                    return@withContext GeminiResult.Error(errMsg)
                }

                val text = extractText(bodyString)
                if (text.isNullOrBlank()) {
                    GeminiResult.Error("Resposta vazia do modelo.")
                } else {
                    GeminiResult.Success(text)
                }
            }
        } catch (e: IOException) {
            GeminiResult.Error("Falha de rede: ${e.message}")
        } catch (e: Exception) {
            GeminiResult.Error("Erro inesperado: ${e.message}")
        }
    }

    private fun buildRequestBody(history: List<ChatMessage>): JSONObject {
        val contents = JSONArray()

        for (msg in history) {
            val role = if (msg.role == ChatRole.USER) "user" else "model"
            val part = JSONObject().put("text", msg.content)
            val entry = JSONObject()
                .put("role", role)
                .put("parts", JSONArray().put(part))
            contents.put(entry)
        }

        val systemInstruction = JSONObject()
            .put(
                "parts",
                JSONArray().put(JSONObject().put("text", VeritySystemPrompt.build()))
            )

        return JSONObject()
            .put("contents", contents)
            .put("system_instruction", systemInstruction)
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.9)
                    .put("maxOutputTokens", 512)
            )
    }

    private fun extractText(responseBody: String): String? {
        return try {
            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates") ?: return null
            if (candidates.length() == 0) return null
            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                sb.append(parts.getJSONObject(i).optString("text"))
            }
            sb.toString()
        } catch (e: Exception) {
            null
        }
    }
}
