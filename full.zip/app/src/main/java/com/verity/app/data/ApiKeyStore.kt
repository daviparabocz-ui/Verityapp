package com.verity.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Modelo Gemini padrão usado se o usuário nunca escolheu outro. */
const val DEFAULT_GEMINI_MODEL = "gemini-3.8-flash"

/** Guarda a API key e as preferências do Gemini localmente, criptografadas. */
class ApiKeyStore(context: Context) {

    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            "verity_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun getKey(): String? = prefs.getString(KEY_API_KEY, null)

    fun saveKey(key: String) {
        prefs.edit().putString(KEY_API_KEY, key.trim()).apply()
    }

    fun clearKey() {
        prefs.edit().remove(KEY_API_KEY).apply()
    }

    fun hasKey(): Boolean = !getKey().isNullOrBlank()

    fun getModel(): String = prefs.getString(KEY_MODEL, DEFAULT_GEMINI_MODEL) ?: DEFAULT_GEMINI_MODEL

    fun saveModel(model: String) {
        prefs.edit().putString(KEY_MODEL, model.trim()).apply()
    }

    companion object {
        private const val KEY_API_KEY = "gemini_api_key"
        private const val KEY_MODEL = "gemini_model"
    }
}
