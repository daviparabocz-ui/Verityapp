package com.verity.app.data

import android.content.Context
import android.content.SharedPreferences
import android.security.KeyPairGeneratorSpec
import android.util.Base64
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.util.Calendar
import javax.crypto.Cipher
import javax.security.auth.x500.X500Principal

/** Modelo Gemini padrão usado se o usuário nunca escolheu outro. */
const val DEFAULT_GEMINI_MODEL = "gemini-3.8-flash"

/**
 * Guarda a API key e as preferências do Gemini localmente.
 *
 * `androidx.security:security-crypto` (EncryptedSharedPreferences) exige API 23+,
 * o que não serve pra API 19. Em vez disso, usamos a técnica padrão da era
 * KitKat para isso: o AndroidKeyStore já existe desde a API 18, só que até a
 * API 22 ele só guarda pares de chave RSA (chaves AES simétricas só chegaram
 * na API 23). Então geramos um par RSA dentro do AndroidKeyStore (nunca sai
 * dali, nem em memória) e usamos a chave pública para "embrulhar" a API key
 * antes de gravar em SharedPreferences normais; a chave privada (que nunca
 * deixa o keystore do sistema) é usada só para ler de volta.
 *
 * Isso não é tão forte quanto uma EncryptedSharedPreferences moderna com
 * chave AES em hardware, mas é a abordagem real usada por apps da época e é
 * bem melhor do que gravar em texto puro.
 */
class ApiKeyStore(private val context: Context) {

    private val prefs: SharedPreferences by lazy {
        context.getSharedPreferences("verity_prefs", Context.MODE_PRIVATE)
    }

    fun getKey(): String? {
        val encoded = prefs.getString(KEY_API_KEY_ENC, null) ?: return null
        return try {
            decrypt(encoded)
        } catch (e: Exception) {
            // Chave do keystore não existe mais (ex: app reinstalado) ou dado corrompido.
            null
        }
    }

    fun saveKey(key: String) {
        val encrypted = encrypt(key.trim())
        prefs.edit().putString(KEY_API_KEY_ENC, encrypted).apply()
    }

    fun clearKey() {
        prefs.edit().remove(KEY_API_KEY_ENC).apply()
    }

    fun hasKey(): Boolean = !getKey().isNullOrBlank()

    fun getModel(): String = prefs.getString(KEY_MODEL, DEFAULT_GEMINI_MODEL) ?: DEFAULT_GEMINI_MODEL

    fun saveModel(model: String) {
        prefs.edit().putString(KEY_MODEL, model.trim()).apply()
    }

    // --- AndroidKeyStore (RSA-wrap) ---

    private fun androidKeyStore(): KeyStore =
        KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    private fun getOrCreateKeyPair(): KeyStore.PrivateKeyEntry {
        val keyStore = androidKeyStore()
        val existing = keyStore.getEntry(KEYSTORE_ALIAS, null) as? KeyStore.PrivateKeyEntry
        if (existing != null) return existing

        val start = Calendar.getInstance()
        val end = Calendar.getInstance().apply { add(Calendar.YEAR, 25) }

        val spec = KeyPairGeneratorSpec.Builder(context)
            .setAlias(KEYSTORE_ALIAS)
            .setSubject(X500Principal("CN=$KEYSTORE_ALIAS"))
            .setSerialNumber(BigInteger.ONE)
            .setStartDate(start.time)
            .setEndDate(end.time)
            .build()

        val generator = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore")
        generator.initialize(spec)
        generator.generateKeyPair()

        return keyStore.getEntry(KEYSTORE_ALIAS, null) as KeyStore.PrivateKeyEntry
    }

    private fun encrypt(plainText: String): String {
        val entry = getOrCreateKeyPair()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, entry.certificate.publicKey)
        val bytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun decrypt(encoded: String): String {
        val entry = getOrCreateKeyPair()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, entry.privateKey)
        val bytes = cipher.doFinal(Base64.decode(encoded, Base64.NO_WRAP))
        return String(bytes, Charsets.UTF_8)
    }

    companion object {
        private const val KEY_API_KEY_ENC = "gemini_api_key_enc"
        private const val KEY_MODEL = "gemini_model"
        private const val KEYSTORE_ALIAS = "verity_api_key_wrap"
        // RSA "puro" (sem OAEP) é o que existia de forma confiável nos provedores
        // do AndroidKeyStore da época; a API key é curta o bastante para caber
        // no limite de payload de uma chave RSA-2048 com esse padding.
        private const val TRANSFORMATION = "RSA/ECB/PKCS1Padding"
    }
}
