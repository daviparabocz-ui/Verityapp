package com.verity.app.ui.chat

import android.app.Activity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import com.verity.app.R
import com.verity.app.data.ApiKeyStore
import com.verity.app.data.DEFAULT_GEMINI_MODEL

/**
 * Modelos Gemini conhecidos no momento em que este app foi escrito.
 * A Google costuma descontinuar modelos com alguma frequência, então
 * também oferecemos "Personalizado..." para o usuário digitar qualquer
 * string de modelo nova sem precisar de uma atualização do app.
 */
private val KNOWN_MODELS = listOf(
    "gemini-3.8-flash",
    "gemini-3.7-flash",
    "gemini-3.5-flash",
    "gemini-3.1-pro",
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite"
)

private const val CUSTOM_OPTION = "Personalizado..."

/**
 * Tela de configurações em Views/XML — o equivalente direto do
 * SettingsScreen do Compose, com o Spinner nativo do Holo no lugar do
 * ExposedDropdownMenu do Material3.
 *
 * Fala direto com o ApiKeyStore (não com o ChatViewModel da MainActivity,
 * que vive em outra Activity); a MainActivity relê o estado no onResume.
 */
class SettingsActivity : Activity() {

    private lateinit var apiKeyStore: ApiKeyStore

    private lateinit var inputApiKey: EditText
    private lateinit var btnSaveKey: Button
    private lateinit var btnClearKey: Button
    private lateinit var spinnerModel: Spinner
    private lateinit var customModelGroup: View
    private lateinit var inputCustomModel: EditText
    private lateinit var btnUseCustomModel: Button
    private lateinit var currentModelText: TextView
    private lateinit var btnRestoreDefault: Button

    private lateinit var spinnerOptions: List<String>
    private var suppressSpinnerCallback = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        title = "Configurações"
        actionBar?.setDisplayHomeAsUpEnabled(true)

        apiKeyStore = ApiKeyStore(applicationContext)

        bindViews()
        setupModelSpinner()
        wireListeners()
        refreshKeySection()
        refreshModelSummary()
    }

    private fun bindViews() {
        inputApiKey = findViewById(R.id.input_api_key)
        btnSaveKey = findViewById(R.id.btn_save_key)
        btnClearKey = findViewById(R.id.btn_clear_key)
        spinnerModel = findViewById(R.id.spinner_model)
        customModelGroup = findViewById(R.id.custom_model_group)
        inputCustomModel = findViewById(R.id.input_custom_model)
        btnUseCustomModel = findViewById(R.id.btn_use_custom_model)
        currentModelText = findViewById(R.id.current_model_text)
        btnRestoreDefault = findViewById(R.id.btn_restore_default_model)
    }

    private fun setupModelSpinner() {
        spinnerOptions = KNOWN_MODELS + CUSTOM_OPTION
        // android.R.layout.simple_spinner_dropdown_item = o item de lista Holo padrão.
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, spinnerOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerModel.adapter = adapter

        val currentModel = apiKeyStore.getModel()
        val isKnown = currentModel in KNOWN_MODELS
        selectSpinnerSilently(if (isKnown) currentModel else CUSTOM_OPTION)
        customModelGroup.visibility = if (isKnown) View.GONE else View.VISIBLE
        if (!isKnown) inputCustomModel.setText(currentModel)
    }

    private fun selectSpinnerSilently(value: String) {
        suppressSpinnerCallback = true
        spinnerModel.setSelection(spinnerOptions.indexOf(value).coerceAtLeast(0))
        suppressSpinnerCallback = false
    }

    private fun wireListeners() {
        btnSaveKey.setOnClickListener {
            val key = inputApiKey.text.toString()
            if (key.isNotBlank()) {
                apiKeyStore.saveKey(key)
                finish()
            }
        }

        btnClearKey.setOnClickListener {
            apiKeyStore.clearKey()
            refreshKeySection()
        }

        spinnerModel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (suppressSpinnerCallback) return
                val selected = spinnerOptions[position]
                if (selected == CUSTOM_OPTION) {
                    customModelGroup.visibility = View.VISIBLE
                } else {
                    customModelGroup.visibility = View.GONE
                    apiKeyStore.saveModel(selected)
                    refreshModelSummary()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        btnUseCustomModel.setOnClickListener {
            val model = inputCustomModel.text.toString()
            if (model.isNotBlank()) {
                apiKeyStore.saveModel(model)
                refreshModelSummary()
            }
        }

        btnRestoreDefault.setOnClickListener {
            apiKeyStore.saveModel(DEFAULT_GEMINI_MODEL)
            val isKnown = DEFAULT_GEMINI_MODEL in KNOWN_MODELS
            selectSpinnerSilently(if (isKnown) DEFAULT_GEMINI_MODEL else CUSTOM_OPTION)
            customModelGroup.visibility = if (isKnown) View.GONE else View.VISIBLE
            refreshModelSummary()
        }
    }

    private fun refreshKeySection() {
        btnClearKey.visibility = if (apiKeyStore.hasKey()) View.VISIBLE else View.GONE
    }

    private fun refreshModelSummary() {
        val model = apiKeyStore.getModel()
        currentModelText.text = "Modelo atual: $model"
        btnRestoreDefault.visibility = if (model != DEFAULT_GEMINI_MODEL) View.VISIBLE else View.GONE
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
