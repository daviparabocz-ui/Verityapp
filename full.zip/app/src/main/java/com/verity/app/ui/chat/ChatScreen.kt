package com.verity.app.ui.chat

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.verity.app.domain.ChatAttachment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Tamanho máximo aceito para um anexo (a API do Gemini tem um limite de payload inline). */
private const val MAX_ATTACHMENT_BYTES = 15L * 1024 * 1024

private class AttachmentTooLargeException : Exception()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onOpenSettings: () -> Unit
) {
    var inputText by rememberSaveable { mutableStateOf("") }
    var showAttachMenu by remember { mutableStateOf(false) }
    var attachmentError by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Um único launcher: a diferença entre "mídia" e "arquivo" é só a lista de
    // mimeTypes passada em launch(), o resto do fluxo (ler, codificar, anexar) é igual.
    val attachmentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        coroutineScope.launch {
            try {
                val attachment = readAttachment(context, uri)
                viewModel.attachPendingFile(attachment)
                attachmentError = null
            } catch (e: AttachmentTooLargeException) {
                attachmentError = "Arquivo muito grande (máx. 15 MB)."
            } catch (e: Exception) {
                attachmentError = "Não foi possível ler o arquivo."
            }
        }
    }

    val canAttach = viewModel.hasApiKey && !viewModel.isBusy

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Verity") },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Text("⚙")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))

            // Sprite do Verity (parado; só troca de frame conforme a animação/humor atual).
            Image(
                painter = painterResource(id = viewModel.animator.currentDrawableRes),
                contentDescription = "Verity",
                modifier = Modifier.size(160.dp)
            )

            Spacer(Modifier.height(16.dp))

            // Toggle de depuração: mostra o texto bruto (com as tags <>) em vez do texto animado.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.End
            ) {
                Text(
                    text = "Ver bruto",
                    style = MaterialTheme.typography.labelMedium
                )
                Switch(
                    checked = viewModel.showRawResponse,
                    onCheckedChange = { viewModel.updateShowRawResponse(it) }
                )
            }

            // --- Caixa de OUTPUT: resposta do Verity ---
            // Card padrão do Material3, flexível em altura e scrollável,
            // para respostas longas não ficarem cortadas.
            val bubbleScroll = rememberScrollState()
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .heightIn(min = 120.dp, max = 260.dp)
            ) {
                Column(
                    modifier = Modifier
                        .verticalScroll(bubbleScroll)
                        .padding(16.dp)
                ) {
                    if (viewModel.showRawResponse) {
                        Text(
                            text = viewModel.lastRawResponse,
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
                        )
                    } else {
                        Text(
                            text = viewModel.displayedText,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }

            viewModel.errorMessage?.let { msg ->
                Spacer(Modifier.height(8.dp))
                Text(
                    text = msg,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
            }

            Spacer(Modifier.weight(1f))

            if (!viewModel.hasApiKey) {
                Text(
                    text = "Configure sua API key do Gemini nas configurações (⚙) para começar.",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            // --- Botão de anexo: deixa mostrar mídia ou arquivo pro Verity analisar ---
            Box {
                TextButton(
                    onClick = { showAttachMenu = true },
                    enabled = canAttach
                ) {
                    Text("📎 Mostrar algo para o Verity")
                }
                DropdownMenu(
                    expanded = showAttachMenu,
                    onDismissRequest = { showAttachMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("🎬 Mídia (áudio, vídeo, música)") },
                        onClick = {
                            showAttachMenu = false
                            attachmentPickerLauncher.launch(arrayOf("audio/*", "video/*"))
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("📄 Arquivo") },
                        onClick = {
                            showAttachMenu = false
                            attachmentPickerLauncher.launch(arrayOf("*/*"))
                        }
                    )
                }
            }

            // Prévia do anexo escolhido, com opção de remover antes de enviar.
            viewModel.pendingAttachment?.let { attachment ->
                AssistChip(
                    onClick = { viewModel.clearPendingAttachment() },
                    label = { Text(attachment.displayName) },
                    trailingIcon = { Text("✕") },
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
                )
            }

            attachmentError?.let { msg ->
                Text(
                    text = msg,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
            }

            // --- Caixa de INPUT: onde o usuário digita ---
            // Campo de texto padrão do Material3, sem sprite customizado.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    enabled = viewModel.hasApiKey && !viewModel.isBusy,
                    placeholder = { Text("Fale com o Verity...") },
                    modifier = Modifier.weight(1f)
                )

                if (viewModel.isBusy) {
                    CircularProgressIndicator(modifier = Modifier.size(32.dp))
                } else {
                    Button(
                        onClick = {
                            viewModel.sendMessage(inputText)
                            inputText = ""
                        },
                        enabled = viewModel.hasApiKey &&
                            (inputText.isNotBlank() || viewModel.pendingAttachment != null)
                    ) {
                        Text("Enviar")
                    }
                }
            }
        }
    }
}

/**
 * Lê o conteúdo de [uri] via ContentResolver, valida o tamanho e devolve já
 * codificado em base64, pronto para ir na requisição pro Gemini. Roda em
 * background (IO) porque envolve leitura de arquivo, potencialmente grande.
 */
private suspend fun readAttachment(context: Context, uri: Uri): ChatAttachment =
    withContext(Dispatchers.IO) {
        val resolver = context.contentResolver

        var displayName = "arquivo"
        var declaredSize: Long? = null
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex >= 0) cursor.getString(nameIndex)?.let { displayName = it }
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) declaredSize = cursor.getLong(sizeIndex)
            }
        }

        if ((declaredSize ?: 0L) > MAX_ATTACHMENT_BYTES) {
            throw AttachmentTooLargeException()
        }

        val mimeType = resolver.getType(uri) ?: "application/octet-stream"

        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Não foi possível abrir o arquivo.")

        if (bytes.size > MAX_ATTACHMENT_BYTES) {
            throw AttachmentTooLargeException()
        }

        ChatAttachment(
            displayName = displayName,
            mimeType = mimeType,
            base64Data = Base64.encodeToString(bytes, Base64.NO_WRAP)
        )
    }
