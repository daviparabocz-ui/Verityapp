package com.verity.app.ui.chat

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.ImageView
import com.verity.app.R

/**
 * Cores da UI de chat. Definidas aqui (em vez de espalhadas pelos Composables)
 * para ficar fácil ajustar a paleta depois que novos sprites chegarem.
 */
private val OutputBubbleColor = Color(0xFF2A2E45) // caixa de resposta do Verity (painel translúcido)
private val InputTextColor = Color(0xFF3A3A3A)    // texto digitado, para contrastar com o sprite claro da caixa de input

/** Duração de uma volta completa do sol girando no fundo. Lento e contínuo, como pedido. */
private const val BG_SPIN_DURATION_MS = 40_000

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onOpenSettings: () -> Unit
) {
    var inputText by rememberSaveable { mutableStateOf("") }

    Box(modifier = Modifier.fillMaxSize()) {
        // --- Background: sol girando infinitamente atrás de todo o conteúdo ---
        val infiniteTransition = rememberInfiniteTransition(label = "bg_spin")
        val rotation by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = BG_SPIN_DURATION_MS, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "bg_spin_angle"
        )
        Image(
            painter = painterResource(id = R.drawable.verity_bg_spin),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .rotate(rotation)
        )

        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text("Verity") },
                    colors = androidx.compose.material3.TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent
                    ),
                    actions = {
                        IconButton(onClick = onOpenSettings) {
                            Text("⚙")
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .imePadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(24.dp))

                // Sprite do Verity (fica parado no primeiro plano, só o fundo gira)
                Image(
                    painter = painterResource(id = viewModel.animator.currentDrawableRes),
                    contentDescription = "Verity",
                    modifier = Modifier.size(160.dp)
                )

                Spacer(Modifier.height(16.dp))

                // Toggle de depuração: mostra o texto bruto (com as tags <>) em vez do texto animado.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "Ver bruto",
                        style = MaterialTheme.typography.labelMedium
                    )
                    Switch(
                        checked = viewModel.showRawResponse,
                        onCheckedChange = { viewModel.setShowRawResponse(it) }
                    )
                }

                // --- Caixa de OUTPUT: resposta do Verity ---
                // Painel estilizado (cor própria), flexível em altura e scrollável,
                // para respostas longas não ficarem cortadas.
                val bubbleScroll = rememberScrollState()
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                        .background(
                            OutputBubbleColor,
                            shape = RoundedCornerShape(16.dp)
                        )
                        .heightIn(min = 120.dp, max = 260.dp)
                        .verticalScroll(bubbleScroll)
                        .padding(16.dp)
                ) {
                    if (viewModel.showRawResponse) {
                        Text(
                            text = viewModel.lastRawResponse,
                            color = Color.White,
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
                        )
                    } else {
                        Text(
                            text = viewModel.displayedText,
                            color = Color.White,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }

                viewModel.errorMessage?.let { msg ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = msg,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                }

                Spacer(Modifier.weight(1f))

                if (!viewModel.hasApiKey) {
                    Text(
                        text = "Configure sua API key do Gemini nas configurações (⚙) para começar.",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                // --- Caixa de INPUT: onde o usuário digita ---
                // Usa o sprite verity_input_box (9-patch) como fundo: uma "pílula" que
                // estica só no meio (as pontas arredondadas nunca são deformadas), com
                // visual distinto da caixa de output, como pedido.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                    ) {
                        // 9-patch (.9.png): precisa ser desenhado via ImageView (View system),
                        // não via Image/painterResource do Compose — só o ImageView respeita
                        // as marcações de região esticável do 9-patch. Com Image comum, a
                        // imagem seria esticada por inteiro e as pontas arredondadas
                        // distorceriam quando a caixa crescesse.
                        AndroidView(
                            factory = { context ->
                                ImageView(context).apply {
                                    setImageResource(R.drawable.verity_input_box)
                                    scaleType = ImageView.ScaleType.FIT_XY
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 20.dp, vertical = 12.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (inputText.isEmpty()) {
                                Text(
                                    text = "Fale com o Verity...",
                                    color = InputTextColor.copy(alpha = 0.5f),
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                            BasicTextField(
                                value = inputText,
                                onValueChange = { inputText = it },
                                enabled = viewModel.hasApiKey && !viewModel.isBusy,
                                textStyle = MaterialTheme.typography.bodyLarge.copy(color = InputTextColor),
                                modifier = Modifier.fillMaxWidth(),
                                cursorBrush = androidx.compose.ui.graphics.SolidColor(InputTextColor)
                            )
                        }
                    }

                    if (viewModel.isBusy) {
                        CircularProgressIndicator(modifier = Modifier.size(32.dp))
                    } else {
                        Button(
                            onClick = {
                                viewModel.sendMessage(inputText)
                                inputText = ""
                            },
                            enabled = viewModel.hasApiKey && inputText.isNotBlank()
                        ) {
                            Text("Enviar")
                        }
                    }
                }
            }
        }
    }
}
