plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.verity.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.verity.app"
        // API 19 = Android 4.4 KitKat. Sem Compose (que exige API 21+):
        // interface toda em Views/XML clássicas, usando os widgets nativos
        // do tema Holo (é o próprio SO que desenha os botões/toggles/fundo
        // no estilo KitKat, sem precisarmos simular nada).
        minSdk = 19
        targetSdk = 19
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Core / arquitetura (sem Compose). ViewModel + LiveData continuam
    // disponíveis em minSdk 19 normalmente, só a parte de UI declarativa
    // (Compose) que exige API 21+.
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.2")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.6.2")

    // Networking (Gemini REST API). OkHttp 4.x exige API 21+; 3.12.x é a
    // última série mantida com suporte a API 9+, então usamos ela aqui.
    implementation("com.squareup.okhttp3:okhttp:3.12.13")
    // org.json já vem embutido no próprio Android SDK, não precisa de dependência.

    // Coroutines (rede em background + efeito de "máquina de escrever").
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    // OBS: androidx.security:security-crypto (EncryptedSharedPreferences) exige
    // API 23+, então a API key é protegida por uma implementação própria
    // baseada em AndroidKeyStore com RSA (disponível desde a API 18) — ver
    // ApiKeyStore.kt.
}
