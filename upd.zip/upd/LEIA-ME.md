# Atualização visual: background girando + caixas de texto customizadas

Extraia por cima do projeto existente (mesma estrutura de pastas).

## O que mudou

### 1. Background girando
- Novo sprite `verity_bg_spin.png` (convertido do seu `costume2.svg`, o "sol"
  laranja raiado) em `res/drawable-nodpi/`.
- Fica atrás de TODO o conteúdo (sprite do Verity, chat, input), girando
  continuamente e devagar (uma volta a cada 40 segundos — ajuste
  `BG_SPIN_DURATION_MS` no topo de `ChatScreen.kt` se quiser mais rápido/lento).
- Usa `ContentScale.Crop` para preencher a tela toda sem distorcer a
  proporção da imagem original.

### 2. Caixa de output (resposta do Verity)
- Continua sendo um painel Compose normal, mas agora com cor própria
  (`OutputBubbleColor`, roxo escuro) em vez da cor genérica do Material3,
  pra ficar visualmente distinta da caixa de input.

### 3. Caixa de input (onde você digita)
- Usa seu `costume8.png` (a "pílula" cinza) como fundo, convertido para
  **9-patch** (`verity_input_box.9.png` em `res/drawable/` — atenção,
  pasta diferente da `drawable-nodpi`, isso é exigido pelo formato).
- 9-patch = a imagem estica só na região central, sem nunca deformar as
  pontas arredondadas, não importa o quanto o texto digitado cresça a caixa.
- Tecnicamente: como 9-patch é um recurso do sistema de Views do Android, e
  não existe nativamente em Compose puro, a caixa é renderizada via
  `AndroidView` + `ImageView` (com `scaleType = FIT_XY`), que é o único jeito
  de fato respeitar os patches. Um `Image`/`painterResource` comum do Compose
  ESTICARIA a imagem inteira e distorceria as pontas — por isso não foi
  usado esse caminho mais simples.
- O texto digitado usa `BasicTextField` transparente por cima da imagem,
  com cor escura para contrastar com o fundo claro da pílula.

## Arquivos neste pacote
```
app/src/main/java/com/verity/app/ui/chat/ChatScreen.kt
app/src/main/res/drawable/verity_input_box.9.png       (NOVO — pasta drawable, não drawable-nodpi)
app/src/main/res/drawable-nodpi/verity_bg_spin.png      (NOVO)
```

## Não testado em emulador
Não tenho como rodar um emulador Android aqui, então essa é a primeira vez
que este layout específico (background rotativo + 9-patch via AndroidView)
é visto renderizado de verdade — vale conferir com atenção no primeiro build:
- Se o sol de fundo cobre bem a tela inteira durante toda a rotação (cantos
  não deveriam "sumir" ou deixar áreas vazias)
- Se a caixa de input estica sem esticar/distorcer as pontas arredondadas
  quando o texto fica longo
- Se o contraste do texto digitado (cinza escuro) está legível sobre o
  sprite da pílula

Se algo não ficar exatamente como esperado, me manda um print que eu ajusto.
